"""Entry point for cisc179."""

from .cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
